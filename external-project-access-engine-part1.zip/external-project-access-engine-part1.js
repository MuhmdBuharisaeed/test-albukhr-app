/* =========================================================
   ALBUKHR EXTERNAL PROJECT ACCESS ENGINE v1
   PART 1 / 4
   Supabase • External Projects Access Control
========================================================= */

/*
  PURPOSE
  -------
  Central access-control engine for external projects.

  TABLE:
    external_project_access

  DEPENDS ON:
    1) js/supabase-core.js
    2) js/external/external-project-engine.js

  REQUIRED FROM external-project-engine.js:
    - getExternalProject(projectIdOrCode)
      OR
    - getExternalProjectById(projectId)
      OR
    - getExternalProjectByCode(projectCode)

  CANONICAL TABLE COLUMNS
  -----------------------
    id
    project_id
    project_code
    userid
    username
    wallet_address
    access_role
    permissions
    status
    starts_at
    expires_at
    granted_by
    granted_by_username
    reason
    metadata
    created_at
    updated_at

  IMPORTANT
  ---------
  This engine is NOT a replacement for Supabase RLS.
  RLS must remain the final authorization boundary.

  `permissions` and `metadata` are expected to be JSON/JSONB columns.
  `status` should normally use:
      active | revoked | expired | pending

  `access_role` examples:
      owner
      admin
      manager
      reviewer
      editor
      contributor
      viewer

  This engine deliberately avoids hard-coding a small permission list.
  Applications can use permission strings such as:
      project.view
      project.edit
      project.manage
      team.view
      team.manage
      documents.view
      documents.manage
      media.view
      media.manage
      reviews.view
      reviews.manage
      comments.view
      comments.manage
      updates.view
      updates.manage
      funding.view
      funding.manage
      wallets.view
      wallets.manage
      activity.view
      access.manage
*/

/* =========================================================
   TABLE CONFIG
========================================================= */

const EXTERNAL_ACCESS_TABLE = "external_project_access";

/* =========================================================
   DEFAULTS
========================================================= */

const EXTERNAL_ACCESS_DEFAULT_ROLE = "viewer";

const EXTERNAL_ACCESS_DEFAULT_STATUS = "active";

const EXTERNAL_ACCESS_DEFAULT_PERMISSIONS = [
  "project.view"
];

/* =========================================================
   SUPABASE CLIENT
========================================================= */

function getExternalAccessSupabaseClient(){

  if(
    typeof window.getAlbukhrSupabaseClient === "function"
  ){

    const client =
      window.getAlbukhrSupabaseClient();

    if(client){
      return client;
    }

  }

  if(window.albukhrSupabase){
    return window.albukhrSupabase;
  }

  console.warn(
    "external-project-access-engine: " +
    "ALBUKHR Supabase Core client not found. " +
    "Load js/supabase-core.js first."
  );

  return null;

}

/* =========================================================
   SAFE HELPERS
========================================================= */

function externalAccessSafeString(
  value,
  fallback = ""
){

  if(
    value === null ||
    value === undefined
  ){
    return fallback;
  }

  return String(value);

}


function externalAccessSafeNumber(
  value,
  fallback = 0
){

  const n = Number(value);

  return Number.isFinite(n)
    ? n
    : fallback;

}


function externalAccessArray(
  value,
  fallback = []
){

  if(Array.isArray(value)){
    return value;
  }

  return fallback;

}


function externalAccessObject(
  value,
  fallback = {}
){

  if(
    value &&
    typeof value === "object" &&
    !Array.isArray(value)
  ){
    return value;
  }

  return fallback;

}


function externalAccessNowISO(){

  return new Date().toISOString();

}


function externalAccessNormalizeRole(
  role
){

  const value =
    externalAccessSafeString(
      role,
      EXTERNAL_ACCESS_DEFAULT_ROLE
    )
    .trim()
    .toLowerCase();

  return value || EXTERNAL_ACCESS_DEFAULT_ROLE;

}


function externalAccessNormalizeStatus(
  status
){

  const value =
    externalAccessSafeString(
      status,
      EXTERNAL_ACCESS_DEFAULT_STATUS
    )
    .trim()
    .toLowerCase();

  return value || EXTERNAL_ACCESS_DEFAULT_STATUS;

}


/* =========================================================
   ASSERT DEPENDENCIES
========================================================= */

function assertExternalAccessDependencies(){

  const supabase =
    getExternalAccessSupabaseClient();

  if(!supabase){

    throw new Error(
      "Supabase Core client is required before " +
      "external-project-access-engine.js"
    );

  }

  if(
    typeof getExternalProject !== "function" &&
    typeof getExternalProjectById !== "function" &&
    typeof getExternalProjectByCode !== "function"
  ){

    throw new Error(
      "external-project-engine.js must expose " +
      "getExternalProject(), getExternalProjectById(), " +
      "or getExternalProjectByCode()"
    );

  }

  return supabase;

}


/* =========================================================
   PROJECT RESOLUTION
========================================================= */

async function resolveExternalAccessProject(
  project
){

  if(
    project === null ||
    project === undefined ||
    project === ""
  ){
    return null;
  }


  /*
    Prefer the generic resolver when available.
  */

  if(
    typeof getExternalProject === "function"
  ){

    try{

      const result =
        await getExternalProject(project);

      if(result && !result.error){
        return result;
      }

    }catch(e){

      console.warn(
        "getExternalProject() resolution failed:",
        e
      );

    }

  }


  /*
    Numeric UUID/id style resolution.
  */

  if(
    typeof getExternalProjectById === "function"
  ){

    try{

      const result =
        await getExternalProjectById(project);

      if(result && !result.error){
        return result;
      }

    }catch(e){

      console.warn(
        "getExternalProjectById() resolution failed:",
        e
      );

    }

  }


  /*
    Project-code resolution.
  */

  if(
    typeof getExternalProjectByCode === "function"
  ){

    try{

      const result =
        await getExternalProjectByCode(
          project
        );

      if(result && !result.error){
        return result;
      }

    }catch(e){

      console.warn(
        "getExternalProjectByCode() resolution failed:",
        e
      );

    }

  }

  return null;

}


/* =========================================================
   PROJECT IDENTIFIERS
========================================================= */

function getExternalAccessProjectId(
  project
){

  if(
    !project ||
    typeof project !== "object"
  ){
    return null;
  }

  return (
    project.project_id ??
    project.id ??
    project.external_project_id ??
    null
  );

}


function getExternalAccessProjectCode(
  project
){

  if(
    !project ||
    typeof project !== "object"
  ){
    return "";
  }

  return externalAccessSafeString(
    project.project_code ??
    project.code ??
    project.slug ??
    ""
  );

}


/* =========================================================
   NORMALIZE ACCESS ROW
========================================================= */

function normalizeExternalProjectAccessRow(
  row = {}
){

  return {

    id:
      row.id ?? null,

    project_id:
      row.project_id ??
      row.external_project_id ??
      null,

    project_code:
      externalAccessSafeString(
        row.project_code
      ),

    userid:
      externalAccessSafeString(
        row.userid ??
        row.user_id
      ),

    username:
      externalAccessSafeString(
        row.username
      ),

    wallet_address:
      externalAccessSafeString(
        row.wallet_address ??
        row.wallet
      ),

    access_role:
      externalAccessNormalizeRole(
        row.access_role ??
        row.role
      ),

    permissions:
      externalAccessArray(
        row.permissions,
        []
      ),

    status:
      externalAccessNormalizeStatus(
        row.status
      ),

    starts_at:
      row.starts_at ??
      null,

    expires_at:
      row.expires_at ??
      null,

    granted_by:
      externalAccessSafeString(
        row.granted_by
      ),

    granted_by_username:
      externalAccessSafeString(
        row.granted_by_username
      ),

    reason:
      externalAccessSafeString(
        row.reason
      ),

    metadata:
      externalAccessObject(
        row.metadata,
        {}
      ),

    created_at:
      row.created_at ??
      null,

    updated_at:
      row.updated_at ??
      null,

    raw:
      row

  };

}


/* =========================================================
   ACCESS EXPIRY CHECK
========================================================= */

function isExternalProjectAccessExpired(
  access
){

  if(!access){
    return true;
  }

  const expiresAt =
    access.expires_at;

  if(!expiresAt){
    return false;
  }

  const timestamp =
    new Date(expiresAt).getTime();

  if(!Number.isFinite(timestamp)){
    return false;
  }

  return Date.now() >= timestamp;

}


/* =========================================================
   ACCESS START CHECK
========================================================= */

function isExternalProjectAccessStarted(
  access
){

  if(!access){
    return false;
  }

  const startsAt =
    access.starts_at;

  if(!startsAt){
    return true;
  }

  const timestamp =
    new Date(startsAt).getTime();

  if(!Number.isFinite(timestamp)){
    return true;
  }

  return Date.now() >= timestamp;

}


/* =========================================================
   EFFECTIVE ACCESS STATUS
========================================================= */

function getExternalProjectAccessEffectiveStatus(
  access
){

  if(!access){
    return "missing";
  }

  const status =
    externalAccessNormalizeStatus(
      access.status
    );

  if(status === "revoked"){
    return "revoked";
  }

  if(status === "pending"){
    if(
      isExternalProjectAccessStarted(access)
    ){
      if(
        !isExternalProjectAccessExpired(access)
      ){
        return "active";
      }
    }

    return "pending";
  }

  if(
    isExternalProjectAccessExpired(access)
  ){
    return "expired";
  }

  if(
    !isExternalProjectAccessStarted(access)
  ){
    return "pending";
  }

  if(status === "active"){
    return "active";
  }

  return status;

}


/* =========================================================
   BUILD ACCESS PAYLOAD
========================================================= */

function buildExternalProjectAccessPayload({
  project,
  userid,
  username = "",
  wallet_address = "",
  access_role = EXTERNAL_ACCESS_DEFAULT_ROLE,
  permissions = EXTERNAL_ACCESS_DEFAULT_PERMISSIONS,
  status = EXTERNAL_ACCESS_DEFAULT_STATUS,
  starts_at = null,
  expires_at = null,
  granted_by = "",
  granted_by_username = "",
  reason = "",
  metadata = {}
} = {}){

  const projectId =
    getExternalAccessProjectId(project);

  const projectCode =
    getExternalAccessProjectCode(project);

  if(!projectId){
    throw new Error(
      "External project id is required"
    );
  }

  if(!userid){
    throw new Error(
      "User id is required"
    );
  }

  return {

    project_id:
      projectId,

    project_code:
      projectCode,

    userid:
      externalAccessSafeString(
        userid
      ),

    username:
      externalAccessSafeString(
        username
      ),

    wallet_address:
      externalAccessSafeString(
        wallet_address
      ),

    access_role:
      externalAccessNormalizeRole(
        access_role
      ),

    permissions:
      Array.from(
        new Set(
          externalAccessArray(
            permissions,
            EXTERNAL_ACCESS_DEFAULT_PERMISSIONS
          )
          .map(
            permission =>
              externalAccessSafeString(
                permission
              )
              .trim()
              .toLowerCase()
          )
          .filter(Boolean)
        )
      ),

    status:
      externalAccessNormalizeStatus(
        status
      ),

    starts_at:
      starts_at || null,

    expires_at:
      expires_at || null,

    granted_by:
      externalAccessSafeString(
        granted_by
      ),

    granted_by_username:
      externalAccessSafeString(
        granted_by_username
      ),

    reason:
      externalAccessSafeString(
        reason
      ),

    metadata:
      externalAccessObject(
        metadata,
        {}
      )

  };

}


/* =========================================================
   FIND ACCESS ROW
========================================================= */

async function findExternalProjectAccess({
  project_id = null,
  project_code = "",
  userid = "",
  access_role = "",
  status = "",
  includeExpired = true
} = {}){

  const supabase =
    assertExternalAccessDependencies();

  if(
    !project_id &&
    !project_code
  ){
    return [];
  }

  try{

    let query =
      supabase
        .from(EXTERNAL_ACCESS_TABLE)
        .select("*");

    if(project_id){
      query =
        query.eq(
          "project_id",
          project_id
        );
    }

    if(project_code){
      query =
        query.eq(
          "project_code",
          project_code
        );
    }

    if(userid){
      query =
        query.eq(
          "userid",
          userid
        );
    }

    if(access_role){
      query =
        query.eq(
          "access_role",
          externalAccessNormalizeRole(
            access_role
          )
        );
    }

    if(status){
      query =
        query.eq(
          "status",
          externalAccessNormalizeStatus(
            status
          )
        );
    }

    query =
      query.order(
        "created_at",
        {
          ascending:false
        }
      );

    const {
      data,
      error
    } = await query;

    if(error){
      throw error;
    }

    let rows =
      (data || [])
      .map(
        normalizeExternalProjectAccessRow
      );

    if(!includeExpired){

      rows =
        rows.filter(
          row =>
            getExternalProjectAccessEffectiveStatus(
              row
            ) !== "expired"
        );

    }

    return rows;

  }catch(e){

    console.error(
      "findExternalProjectAccess:",
      e
    );

    return [];

  }

}


/* =========================================================
   GET ACCESS FOR ONE USER
========================================================= */

async function getExternalProjectUserAccess(
  project,
  userid
){

  if(!userid){
    return [];
  }

  const resolved =
    await resolveExternalAccessProject(
      project
    );

  if(!resolved){
    return [];
  }

  const projectId =
    getExternalAccessProjectId(
      resolved
    );

  const projectCode =
    getExternalAccessProjectCode(
      resolved
    );

  return await findExternalProjectAccess({
    project_id:projectId,
    project_code:projectCode,
    userid,
    includeExpired:true
  });

}


/* =========================================================
   GET ALL PROJECT ACCESS
========================================================= */

async function getExternalProjectAccessList(
  project,
  options = {}
){

  const resolved =
    await resolveExternalAccessProject(
      project
    );

  if(!resolved){
    return [];
  }

  const projectId =
    getExternalAccessProjectId(
      resolved
    );

  const projectCode =
    getExternalAccessProjectCode(
      resolved
    );

  return await findExternalProjectAccess({

    project_id:
      projectId,

    project_code:
      projectCode,

    access_role:
      options.access_role ||
      "",

    status:
      options.status ||
      "",

    includeExpired:
      options.includeExpired !== false

  });

}


/* =========================================================
   PART 1 END
========================================================= */

/*
  PART 2 will continue with:

  - getExternalProjectAccessById()
  - hasExternalProjectAccess()
  - hasExternalProjectPermission()
  - grantExternalProjectAccess()
  - updateExternalProjectAccess()
  - revokeExternalProjectAccess()

  PART 3 will continue with:

  - role/permission helpers
  - bulk access management
  - expiry handling
  - current-user access helpers

  PART 4 will continue with:

  - dashboard summaries
  - access audit helpers
  - automatic project bootstrap
  - global window exports
*/
